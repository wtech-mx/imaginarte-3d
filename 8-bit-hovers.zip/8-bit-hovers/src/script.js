// add extra elements to buttons for hover, keeps html cleaner
$('.btn').prepend('<div class="hover"><span></span><span></span><span></span><span></span><span></span></div>');

$('.social-btn').prepend('<div class="hover"><span></span><span></span><span></span><span></span></div>');